import React from 'react';
// import logo from './logo.svg';
import {Button, Input, Icon, TimePicker, DatePicker} from 'antd';
import './NewAppointment.css';
import moment from 'moment';

class NewAppointment extends React.Component {
  state;
  constructor(props) {
    super(props);
    this.state = {
      date: '',
      time: '',
      desc: '',
      visible: false,
      errors: [],
      form: {
        time: moment('00:00:00', 'HH:mm:ss')
      }
    };
    this.handleOnChange = this
      .handleOnChange
      .bind(this);
    this.reset = this
      .reset
      .bind(this);
    this.save = this
      .save
      .bind(this);
    this.toggleForm = this
      .toggleForm
      .bind(this);
    this.setTimeState = this
      .setTimeState
      .bind(this);
    this.setDateState = this
      .setDateState
      .bind(this);
    this.validateDate = this
      .validateDate
      .bind(this);
    this.isFormValid = this
      .isFormValid
      .bind(this);
    this.cancel = this
      .cancel
      .bind(this);
    this.getErrors = this
      .getErrors
      .bind(this);
  }

  componentDidMount() {}

  handleOnChange(event) {
    /* console.log(event); //tslint:disable-line
    this.setState({
      [event.currentTarget.name]: event.currentTarget.value
    }); */
    var form = {
      ...this.state.form
    }
    form[event.currentTarget.name] = event.currentTarget.value;
    this.setState({form})
  }

  toggleForm() {
    this.setState({
      visible: !this.state.visible
    });
  }

  cancel() {
    this.reset();
    this.toggleForm();    
  }

  setTimeState(value) {
    var form = {
      ...this.state.form
    }
    form.time = value;
    this.setState({form})
  }

  validateDate(date) {
    if (!!date) {
      return new Date().valueOf() > date.valueOf();
    }
  }

  setDateState(value) {
    var form = {
      ...this.state.form
    }
    form.date = value;
    this.setState({form})
  }

  isFormValid() {
    return !!this.state.form.date && !!this.state.form.time && !!this.state.form.desc;
  }

  save() {
    if (this.isFormValid()) {
      let formData = {
        ...this.state.form
      };
      formData.time = formData
        .time
        .format('hh:mm a');
      formData.date = formData
        .date
        .format('MMM d');
      this
        .props
        .addNew(formData);
      this.toggleForm();
    } else {
      this.setState({errors: []});
      let errors = [];
      if (!this.state.form.date) {
        errors.push('Date is Mandatory. Please select date')
      }
      if (!this.state.form.time) {
        errors.push('Time is Mandatory. Please select time')
      }
      if (!this.state.form.desc) {
        errors.push('Description is Mandatory. Please enter description')
      }
      this.setState({errors: errors});
    }
  }

  getErrors() {
    let messages = [];
    this
      .state
      .errors
      .map((error, index) => {
        messages.push(
          <div className="error" key={index}>{error}</div>
        );
      });
    return messages;
  }

  reset() {
    this.setState({form: {}});
    this.setState({errors: []});
  }

  render() {
    return (
      <div className="NewAppointment">
        {!this.state.visible && <div className="row container">
          <Button
            type="primary"
            className="new-btn has-overlay"
            onClick={this.toggleForm}
            icon="calendar">
            <Icon className="overlay" type="plus-circle-o"/>
            <span className="label">New</span>
          </Button>
        </div>
}
        {!!this.state.visible && <div className="row container">
          <div className="column container">
            {this
              .state
              .errors
              .map((error, index) => {
                return <div className="error" key={index}>
                  <div>{error}</div>
                </div>
              })
}
          </div>
          <form className="row form">
            <div className="buttons">
              <Button type="primary" onClick={this.save}>
                <span className="label">Add</span>
              </Button>
              <Button type="danger" onClick={this.cancel}>
                <span className="label">Cancel</span>
              </Button>
            </div>
            <DatePicker
              onChange={this.setDateState}
              disabledDate={this.validateDate}
              format="MMM d"
              value={this.state.form.date}/>
            <TimePicker
              onChange={this.setTimeState}
              value={this.state.form.time}
              format="hh:mm a"
              defaultOpenValue={moment('00:00:00', 'HH:mm:ss')}/>
            <Input
              placeholder="Description"
              name="desc"
              value={this.state.form.desc}
              onChange={this.handleOnChange}/>
          </form>
        </div>
}
      </div>
    );
  }
}

export default NewAppointment;
