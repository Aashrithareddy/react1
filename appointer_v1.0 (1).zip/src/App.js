import React from 'react';
import logo from './logo.svg';
import {Button, Input, Table} from 'antd';
import './App.css';
import NewAppointment from './NewAppointment/NewAppointment';

class App extends React.Component {
  filteredData = [];
  dataSource = [
    {
      key: '1',
      date: 'May 2',
      time: '11:00am',
      desc: 'Something'
    }, {
      key: '2',
      date: 'May 2',
      time: '12:00pm',
      desc: 'Something else'
    }, {
      key: '3',
      date: 'May 4',
      time: '8:00am',
      desc: 'Meet foo'
    }
  ];

  columns = [
    {
      title: 'Date',
      dataIndex: 'date',
      key: 'date'
    }, {
      title: 'Time',
      dataIndex: 'time',
      key: 'time'
    }, {
      title: 'Description',
      dataIndex: 'desc',
      key: 'desc'
    }
  ];
  state;
  props;
  constructor(props) {
    super(props);
    this.state = {
      searchText: '',
      filteredData: this.dataSource,
      formVisible: false
    };
    this.filteredData = this.dataSource;
    this.handleOnChange = this
      .handleOnChange
      .bind(this);
    this.search = this
      .search
      .bind(this);
    this.toggleForm = this
      .toggleForm
      .bind(this);
    this.addNew = this
      .addNew
      .bind(this);
  }

  toggleForm() {
    this.setState({
      formVisible: !this.state.formVisible
    });
  }

  addNew(form) {
    form.key = this.dataSource.length + 1;
    this
      .dataSource
      .push(form);
    this.search();
  }

  isFormValid() {
    return !!this.state.form.date && !!this.state.form.time && !!this.state.form.desc;
  }

  handleOnChange(event) {
    console.log(event); //tslint:disable-line
    this.setState({
      [event.currentTarget.name]: event.currentTarget.value
    });
  }

  search() {
    this.setState({
      filteredData: this
        .dataSource
        .filter((data) => {
          return data
            .desc
            .toLowerCase()
            .indexOf(this.state.searchText.toLowerCase()) !== -1 || data
            .time
            .toLowerCase()
            .indexOf(this.state.searchText.toLowerCase()) !== -1 || data
            .date
            .toLowerCase()
            .indexOf(this.state.searchText.toLowerCase()) !== -1;;
        })
    });
  }

  render() {
    return (
      <div className="App">
        <NewAppointment addNew={(form) => this.addNew(form)}/>
        <div className="row search-container">
          <Input
            placeholder="May be search something..."
            name="searchText"
            type="text"
            value={this.state.searchText}
            onChange={this.handleOnChange}/>
          <Button type="primary" icon="search" onClick={this.search}>Search</Button>
        </div>
        <div className="row result-rab">
          <Table pagination={this.state.filteredData.length > 10} dataSource={this.state.filteredData} columns={this.columns}/>
        </div>
      </div>
    );
  }
}

export default App;
